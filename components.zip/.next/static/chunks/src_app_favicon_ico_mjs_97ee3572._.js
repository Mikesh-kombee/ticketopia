(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_favicon_ico_mjs_97ee3572._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_favicon_ico_mjs_97ee3572._.js",
  "chunks": [
    "static/chunks/f67c7_next_dist_4be8d65a._.js"
  ],
  "source": "dynamic"
});
