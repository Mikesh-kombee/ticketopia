(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/_e69f0d32._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/_e69f0d32._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_6cae2371._.js",
    "static/chunks/f67c7_next_dist_compiled_9df05ec4._.js",
    "static/chunks/f67c7_next_dist_client_68b27bbe._.js",
    "static/chunks/f67c7_next_dist_696fe3da._.js",
    "static/chunks/61dca_@swc_helpers_cjs_e27e0aca._.js"
  ],
  "source": "entry"
});
