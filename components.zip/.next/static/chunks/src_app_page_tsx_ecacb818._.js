(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_ecacb818._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_ecacb818._.js",
  "chunks": [
    "static/chunks/node_modules__pnpm_59ac12fd._.js",
    "static/chunks/src_9e967401._.js"
  ],
  "source": "dynamic"
});
