module.exports = {

"[project]/.next-internal/server/app/api/dashboard/active-engineers/route/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route.runtime.dev.js [external] (next/dist/compiled/next-server/app-route.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page.runtime.dev.js [external] (next/dist/compiled/next-server/app-page.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/src/lib/types.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "alertSeverities": (()=>alertSeverities),
    "alertStatuses": (()=>alertStatuses),
    "alertTypes": (()=>alertTypes),
    "attendanceStatuses": (()=>attendanceStatuses),
    "engineerStatuses": (()=>engineerStatuses),
    "issueTypes": (()=>issueTypes),
    "ticketPriorities": (()=>ticketPriorities),
    "ticketStatuses": (()=>ticketStatuses)
});
const issueTypes = [
    "Plumbing",
    "Electrical",
    "HVAC",
    "Appliance Repair",
    "Other"
];
const ticketStatuses = [
    "Pending",
    "Assigned",
    "In Progress",
    "Completed",
    "Cancelled"
];
const alertTypes = [
    "Speeding",
    "Long Idle",
    "Geofence Breach",
    "Service Due",
    "Unusual Activity"
];
const alertSeverities = [
    "high",
    "medium",
    "low",
    "info"
];
const alertStatuses = [
    "new",
    "reviewed",
    "dismissed"
];
const engineerStatuses = [
    "Active",
    "Offline",
    "On Break",
    "On Route"
];
const ticketPriorities = [
    "Low",
    "Medium",
    "High",
    "Urgent"
];
const attendanceStatuses = [
    "Checked In",
    "Checked Out",
    "Late",
    "Absent",
    "On Leave"
];
}}),
"[project]/src/app/api/dashboard/active-engineers/route.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "GET": (()=>GET)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$2$2e$3_$40$opentelemetry$2b$_e24ce7b903aef3336a8dc91bdc80d2a0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.2.3_@opentelemetry+_e24ce7b903aef3336a8dc91bdc80d2a0/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/types.ts [app-route] (ecmascript)");
;
;
const mockEngineers = [
    {
        id: "eng1",
        name: "Alice Smith",
        status: "Active",
        avatar: "https://placehold.co/40x40.png?text=AS",
        currentTask: "Servicing Ticket #T1001"
    },
    {
        id: "eng2",
        name: "Bob Johnson",
        status: "On Route",
        avatar: "https://placehold.co/40x40.png?text=BJ",
        currentTask: "En route to Downtown"
    },
    {
        id: "eng3",
        name: "Charlie Brown",
        status: "On Break",
        avatar: "https://placehold.co/40x40.png?text=CB"
    },
    {
        id: "eng4",
        name: "Diana Prince",
        status: "Offline",
        avatar: "https://placehold.co/40x40.png?text=DP"
    },
    {
        id: "eng5",
        name: "Edward Nygma",
        status: "Active",
        avatar: "https://placehold.co/40x40.png?text=EN",
        currentTask: "Awaiting Assignment"
    }
];
async function GET() {
    // Simulate API delay
    await new Promise((resolve)=>setTimeout(resolve, 500));
    // Simulate some status changes
    const updatedEngineers = mockEngineers.map((eng)=>{
        if (Math.random() < 0.2) {
            return {
                ...eng,
                status: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["engineerStatuses"][Math.floor(Math.random() * __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["engineerStatuses"].length)]
            };
        }
        return eng;
    });
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$2$2e$3_$40$opentelemetry$2b$_e24ce7b903aef3336a8dc91bdc80d2a0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(updatedEngineers);
}
}}),

};

//# sourceMappingURL=%5Broot%20of%20the%20server%5D__ce6086d6._.js.map