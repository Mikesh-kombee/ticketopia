module.exports = {

"[project]/.next-internal/server/app/api/dashboard/todays-attendance/route/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route.runtime.dev.js [external] (next/dist/compiled/next-server/app-route.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page.runtime.dev.js [external] (next/dist/compiled/next-server/app-page.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/src/lib/types.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "alertSeverities": (()=>alertSeverities),
    "alertStatuses": (()=>alertStatuses),
    "alertTypes": (()=>alertTypes),
    "attendanceStatuses": (()=>attendanceStatuses),
    "engineerStatuses": (()=>engineerStatuses),
    "issueTypes": (()=>issueTypes),
    "ticketPriorities": (()=>ticketPriorities),
    "ticketStatuses": (()=>ticketStatuses)
});
const issueTypes = [
    "Plumbing",
    "Electrical",
    "HVAC",
    "Appliance Repair",
    "Other"
];
const ticketStatuses = [
    "Pending",
    "Assigned",
    "In Progress",
    "Completed",
    "Cancelled"
];
const alertTypes = [
    "Speeding",
    "Long Idle",
    "Geofence Breach",
    "Service Due",
    "Unusual Activity"
];
const alertSeverities = [
    "high",
    "medium",
    "low",
    "info"
];
const alertStatuses = [
    "new",
    "reviewed",
    "dismissed"
];
const engineerStatuses = [
    "Active",
    "Offline",
    "On Break",
    "On Route"
];
const ticketPriorities = [
    "Low",
    "Medium",
    "High",
    "Urgent"
];
const attendanceStatuses = [
    "Checked In",
    "Checked Out",
    "Late",
    "Absent",
    "On Leave"
];
}}),
"[project]/src/app/api/dashboard/todays-attendance/route.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "GET": (()=>GET)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$2$2e$3_$40$opentelemetry$2b$_e24ce7b903aef3336a8dc91bdc80d2a0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.2.3_@opentelemetry+_e24ce7b903aef3336a8dc91bdc80d2a0/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/types.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$3$2e$6$2e$0$2f$node_modules$2f$date$2d$fns$2f$format$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/date-fns@3.6.0/node_modules/date-fns/format.mjs [app-route] (ecmascript) <locals>");
;
;
;
const engineerNames = [
    "Alice Smith",
    "Bob Johnson",
    "Charlie Brown",
    "Diana Prince",
    "Edward Nygma"
];
const mockTodaysAttendance = engineerNames.map((name, i)=>{
    const randomStatus = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["attendanceStatuses"][Math.floor(Math.random() * __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$types$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["attendanceStatuses"].length)];
    let checkInTime;
    let checkOutTime;
    const today = new Date();
    if (randomStatus === "Checked In" || randomStatus === "Late") {
        checkInTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$3$2e$6$2e$0$2f$node_modules$2f$date$2d$fns$2f$format$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(new Date(today.setHours(Math.floor(Math.random() * 2 + 8), Math.floor(Math.random() * 60))), 'HH:mm');
    }
    if (randomStatus === "Checked Out" && Math.random() > 0.5) {
        checkInTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$3$2e$6$2e$0$2f$node_modules$2f$date$2d$fns$2f$format$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(new Date(today.setHours(Math.floor(Math.random() * 2 + 8), Math.floor(Math.random() * 60))), 'HH:mm');
        checkOutTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$3$2e$6$2e$0$2f$node_modules$2f$date$2d$fns$2f$format$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(new Date(today.setHours(Math.floor(Math.random() * 2 + 16), Math.floor(Math.random() * 60))), 'HH:mm');
    }
    return {
        id: `ATT${4000 + i}`,
        engineerId: `eng${i + 1}`,
        engineerName: name,
        checkInTime,
        checkOutTime,
        status: randomStatus,
        avatar: `https://placehold.co/40x40.png?text=${name.substring(0, 1)}${name.split(' ')[1]?.[0] || ''}`,
        date: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$date$2d$fns$40$3$2e$6$2e$0$2f$node_modules$2f$date$2d$fns$2f$format$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(today, 'yyyy-MM-dd')
    };
});
async function GET() {
    await new Promise((resolve)=>setTimeout(resolve, 300));
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$2$2e$3_$40$opentelemetry$2b$_e24ce7b903aef3336a8dc91bdc80d2a0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(mockTodaysAttendance);
}
}}),

};

//# sourceMappingURL=%5Broot%20of%20the%20server%5D__42ce32bc._.js.map