const CHUNK_PUBLIC_PATH = "server/app/api/dashboard/recent-route-logs/route.js";
const runtime = require("../../../../chunks/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/node_modules__pnpm_94517add._.js");
runtime.loadChunk("server/chunks/[root of the server]__e1758e12._.js");
runtime.getOrInstantiateRuntimeModule("[project]/.next-internal/server/app/api/dashboard/recent-route-logs/route/actions.js [app-rsc] (server actions loader, ecmascript)", CHUNK_PUBLIC_PATH);
runtime.getOrInstantiateRuntimeModule("[project]/node_modules/.pnpm/next@15.2.3_@opentelemetry+_e24ce7b903aef3336a8dc91bdc80d2a0/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/dashboard/recent-route-logs/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)", CHUNK_PUBLIC_PATH);
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/node_modules/.pnpm/next@15.2.3_@opentelemetry+_e24ce7b903aef3336a8dc91bdc80d2a0/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/dashboard/recent-route-logs/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)", CHUNK_PUBLIC_PATH).exports;
