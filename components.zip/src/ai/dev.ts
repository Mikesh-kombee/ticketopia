import { config } from 'dotenv';
config();

import '@/ai/flows/issue-categorization.ts';
import '@/ai/flows/engineer-eta.ts';